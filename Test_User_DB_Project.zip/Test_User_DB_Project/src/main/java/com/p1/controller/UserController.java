package com.p1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.p1.model.*;
import com.p1.dao.*;

@RestController
//@CrossOrigin(origins = "http://localhost:4200")
public class UserController 
{
		@Autowired 
		private UserDao uDao;
		
		@GetMapping("/users")
		public List<User> findAll() {
			return uDao.findAll();
		}
		
		@GetMapping("/user/{id}")
		public User findById(@PathVariable int id) {
			return uDao.findById(id);
		}
		
		@DeleteMapping("/user/{id}")
		public String deleteById(@PathVariable int id) {
			return uDao.deleteById(id)+" User(s) deleted from the database";
		}
		
		@PostMapping("/user")
		public String save(@RequestBody User u) {
			return uDao.save(u)+" User saved successfully";
		}
		
		@PutMapping("/users/{id}")
		public String update(@RequestBody User u, @PathVariable int id) {
			return uDao.update(u, id)+" User(s) updated successfully";
		}
		
	}