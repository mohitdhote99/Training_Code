package com.p1.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.p1.model.*;

@Repository
public class UserDaoImpl implements UserDao
{
		@Autowired
		JdbcTemplate jdbcTemplate;
		
		@Override
		public List<User> findAll() 
		{	return jdbcTemplate.query("SELECT * FROM user", new BeanPropertyRowMapper<User>(User.class));
		}

		@Override
		public User findById(int id) {
			return jdbcTemplate.queryForObject("SELECT * FROM user WHERE userId=?",
					                           new BeanPropertyRowMapper<User>(User.class), id);
		}

		@Override
		public int deleteById(int id) {
			return jdbcTemplate.update("DELETE FROM user WHERE userId=?", id);
		}

		@Override
		public int save(User u) {
			return jdbcTemplate.update("INSERT INTO user  VALUES (?, ?, ?, ?)", 
					                                           new Object[] {u.getUserId(), u.getUname(), u.getUdob(), u.getUsalary()});
		}

		@Override
		public int update(User u, int id) {
			return jdbcTemplate.update("UPDATE user SET uname = ?, udob = ?,  usalary= ? WHERE id = ?", 
					                   new Object[] {u.getUname(), u.getUdob(), u.getUsalary(), id});
		}			
}