package com.p1.dao;

import java.util.List;
import com.p1.model.*;

public interface UserDao 
{		
		public List<User> findAll();
		
		public User findById(int id);
		
		public int deleteById(int id);
		
		public int save(User u);
		
		public int update(User u, int id);
 }