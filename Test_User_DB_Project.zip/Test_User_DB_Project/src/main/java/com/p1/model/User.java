package com.p1.model;

import java.util.Date;

public class User 
{
   int userId;
   String uname;
   Date udob;
   double usalary;

   public User()
   { }
   
   public User(int userId, String uname, Date udob, double usalary)
   {
	   this.userId= userId;
	   this.uname= uname;
	   this.udob= udob;
	   this.usalary= usalary;
   }

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public String getUname() {
	return uname;
}

public void setUname(String uname) {
	this.uname = uname;
}

public Date getUdob() {
	return udob;
}

public void setUdob(Date udob) {
	this.udob = udob;
}

public double getUsalary() {
	return usalary;
}

public void setUsalary(double usalary) {
	this.usalary = usalary;
}
  
}
