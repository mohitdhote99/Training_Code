package com.p1;

import org.springframework.stereotype.Controller;  
import org.springframework.web.bind.annotation.RequestMapping;  

@Controller  
public class HelloController 
{  
@RequestMapping("/") // tells the container that display() method is 
                                         // request handler method.
    public String display()  
    {     return "index";  // name of the view
       }     
}  