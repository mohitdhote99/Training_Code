insert into exchange_value values(10001,'EUR','INR',89,0);
insert into exchange_value values(10002,'USD','INR',79,0);
insert into exchange_value values(10003,'THB','INR',3,0);