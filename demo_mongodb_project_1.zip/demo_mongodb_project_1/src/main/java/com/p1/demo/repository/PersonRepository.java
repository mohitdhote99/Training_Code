package com.p1.demo.repository;

import com.p1.demo.model.Person;
import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

@Repository
public interface PersonRepository extends MongoRepository<Person, String>
{
  public Person findByFirstName(String firstName);
  public List<Person> findByAge(int age);
}
