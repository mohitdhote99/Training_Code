package com.p1;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import  com.p1.Employee;

public class App 
{
	public static void main(String args[])
	{
        ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
            EmployeeJdbcTemplate employeeJdbcTemplate = 
               (EmployeeJdbcTemplate)context.getBean("employeeJdbcTemplate");

          // Display current state of Employee table 
          List<Employee> emp = employeeJdbcTemplate.getAllEmployees();
          System.out.println("Current State of employee table -");
          System.out.println(emp); 

          // insert new employee
       //   employeeJdbcTemplate.insertEmployee(201, "Rajdeep", 41, 4000);

          // Display inserted employee  
          Employee insertedEmployee = employeeJdbcTemplate.getEmployeeById(201);
          System.out.println("Inserted Employee Information from Employee Table - ");
          System.out.println(insertedEmployee);

          // update employee
          Employee updatedEmployee = employeeJdbcTemplate.updateEmployee("Prabhu ", 200);
          System.out.println("Updated Employee Information from Employee Table - ");
          System.out.println(updatedEmployee);
        
          //delete employee    
          employeeJdbcTemplate.deleteEmployee(202);

          // display total number of employees        
         // int count = employeeJdbcTemplate.getTotalNumberOfEmployees();        
          System.out.println("Total number of Employees in employee table ");
          //System.out.println(count);

          emp = employeeJdbcTemplate.getAllEmployees();
          System.out.println("Current State of employee table -");
          System.out.println(emp);
          ((AbstractApplicationContext) context).close();
   }
}
