package com.cart.demo.shoppingCartDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartDemoApplicationTests {
/*
	@Test
	void contextLoads() {
	}
*/
}
