/**
 * 
 */
package com.p1.sbsecurity.service;

import com.p1.sbsecurity.bean.CurrentUser;

/**
 * @author Dinesh.Rajput
 *
 */
public interface CurrentUserService {
	
	 boolean canAccessUser(CurrentUser currentUser, Long userId);
}
