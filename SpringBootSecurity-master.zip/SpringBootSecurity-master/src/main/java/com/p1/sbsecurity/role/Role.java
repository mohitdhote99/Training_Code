/**
 * 
 */
package com.p1.sbsecurity.role;

/**
 * @author Dinesh.Rajput
 *
 */
public enum Role {
	USER, ADMIN
}
