/**
 * 
 */
package com.p1.sbsecurity.service;

import java.util.Collection;

import com.p1.sbsecurity.bean.UserBean;
import com.p1.sbsecurity.model.User;

/**
 * @author Dinesh.Rajput
 *
 */
public interface UserService {
	
	User getUserById(long id);

    User getUserByEmail(String email);

    Collection<User> getAllUsers();

    User create(UserBean userBean);
}
