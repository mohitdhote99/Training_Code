package com.p1;

public class Person {
	
    public String name;
 
    public Person()
    { }
    
    public void setName(String name)
    {
        this.name = name;
    }
 
    public String getName()
    {
        return name;
    }
}