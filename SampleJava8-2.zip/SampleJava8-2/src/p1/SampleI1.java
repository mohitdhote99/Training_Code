package p1;

public interface SampleI1 
{
	int a= 25;
  public default void display()
  {	  System.out.println("Wecome to Default methods in I1");
     }
  
  public static void  message()
  { System.out.println("This message is from static method");
     }
  
  public void comment();
  
}
