package p1;

public class SampleC1 implements SampleI1 
{
	//a= 35;
	@Override
	public void comment() 
	{ System.out.println("This is comment in SampleC1");
	   }
}