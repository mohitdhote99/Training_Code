package p1;

public class SampleC2 implements SampleI1 
{
   @Override
	public void comment() 
    {  System.out.println("This is comment in Samplec2"); 
	  }
}
