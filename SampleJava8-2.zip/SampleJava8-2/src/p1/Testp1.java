package p1;

public class Testp1 
{
   public static void main(String args[])
   {
	   SampleC1 obc1= new SampleC1();
	   obc1.display();
	   obc1.comment();
	   SampleC2 obc2= new SampleC2();
	   obc2.display();
	   obc2.comment();
	   //SampleC1.message();
	   //SampleC2.message();
	   SampleI1.message();
 }
}
