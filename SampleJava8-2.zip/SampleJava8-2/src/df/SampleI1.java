package df;

public interface SampleI1 
{
    public default void displayI1()
    { System.out.println("This is default display in SampleI1");
     }
    public default void outputI1()
    { System.out.println("This is in defaut Output1");	
     }
    public void method1();
}
