package df;

public class Testp2 implements SampleI1, SampleI2
{
	public void output()
	{  SampleI1.super.displayI1();
	   SampleI2.super.displayI2();
	}
	public void outputI2()
	{
		
	}
	public void method1()
	{ System.out.println("Inmethod1");
	 }
	public static void main(String[] args) 
	{
	   Testp2  obj= new Testp2();
	   obj.output(); 
	   obj.outputI1();
	   //obj.display();
	   obj.displayI2();
	}
}
