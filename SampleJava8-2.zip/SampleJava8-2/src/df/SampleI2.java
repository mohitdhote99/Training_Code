package df;

public interface SampleI2 
{
   public default void displayI2()
   { System.out.println("This is default display from I2");
     }
   public void outputI2();
}
