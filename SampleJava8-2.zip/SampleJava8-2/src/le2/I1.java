package le2;

public interface I1 
 {  int operation(int a, int b);
   }
