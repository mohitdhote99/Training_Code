package le2;

public class Testp3 //implements I1
{ 
  public static void main(String args[])
   {
	  int op,n1,n2;
	  n1=10; n2=25;
	  int c=0;
	 // I1 iobj = (int a, int b)-> a+b;
	  I1 iobj1 = (int a1, int b1)-> 
	       { 
		     System.out.println("Demo of Multi line");
		       return a1+b1;    
	         }; //n1+n2;
	  op= iobj1.operation(n1,n2);		  
	  System.out.println(op); 
	  I1 iobj2 = (int a1, int b1) -> n2-n1;
	  op= iobj2.operation(n1,n2);
	  System.out.println(op);   
   }
}