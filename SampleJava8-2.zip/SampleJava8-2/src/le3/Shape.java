package le3;

public interface Shape 
{
   double pi=3.147;
   
}
