package annonymous;

public class App {

	public static void main(String... args) {

		HelloWorldAnonymous myApp = new HelloWorldAnonymous();
		myApp.sayHello();

	}
}